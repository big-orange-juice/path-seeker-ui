﻿# Path Seeker Admin 发布包

打包时间：2026-10-13 18:26:11
文件数量：435

## 服务器上执行（需 Node >= 22.12、pnpm 11.x）

    mkdir -p /root/path-seeker
    tar -xzf <本包>.tar.gz -C /root/path-seeker
    cd /root/path-seeker/source_code
    pnpm install --frozen-lockfile
    pnpm build:web-admin              # 必须在 Linux 上构建，Windows 产物里的 sharp 不能用于 Linux
    cd apps/web-admin
    pm2 start ecosystem.config.cjs    # 更新时：pm2 reload path-seeker-admin --update-env
    pm2 save

解压后仓库根目录为 /root/path-seeker/source_code（包内顶层目录 path-seeker-ui 需已就位或改名）。

## 注意

- 环境变量：PM2 的 env 优先级最高，会覆盖 apps/web-admin/.env.production。
  高德 Key 需通过 NUXT_PUBLIC_AMAP_KEY / NUXT_PUBLIC_AMAP_SECURITY_CODE 提供。
- nginx：docs/nginx/path-seeker.conf 已随包提供，需 client_max_body_size >= 420m。
- 本包为源码包，不含 node_modules / .output，需在服务器上构建。
