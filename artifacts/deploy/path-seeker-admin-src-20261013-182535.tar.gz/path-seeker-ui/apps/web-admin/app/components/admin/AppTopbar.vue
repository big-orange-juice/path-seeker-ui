<script setup lang="ts">
import { computed, nextTick, shallowRef } from 'vue';
import Button from '@/components/shadcn/button/Button.vue';
import Dialog from '@/components/shadcn/dialog/Dialog.vue';
import DialogContent from '@/components/shadcn/dialog/DialogContent.vue';
import DialogDescription from '@/components/shadcn/dialog/DialogDescription.vue';
import DialogFooter from '@/components/shadcn/dialog/DialogFooter.vue';
import DialogHeader from '@/components/shadcn/dialog/DialogHeader.vue';
import DialogTitle from '@/components/shadcn/dialog/DialogTitle.vue';
import { useAdminAssistantDrawer } from '@/composables/useAdminAssistantDrawer';
import { useAdminNavigation } from '@/composables/useAdminNavigation';
import { useAdminNavDrawer } from '@/composables/useAdminNavDrawer';
import { useAdminTipsGuide } from '@/composables/useAdminTipsGuide';
import { useAdminAuthStore } from '@/stores/adminAuth';
import { ADMIN_LOGIN_PATH } from '@/constants/admin-auth';

const route = useRoute();
const authStore = useAdminAuthStore();
const { navItems } = useAdminNavigation();
const { open, openNav } = useAdminNavDrawer();
const { openManually: openTips } = useAdminTipsGuide();
const { open: assistantOpen, openAssistant } = useAdminAssistantDrawer();

const logoutConfirmOpen = shallowRef(false);
const loggingOut = shallowRef(false);

const currentPage = computed(() => {
  return navItems.value.find((item) => item.to === route.path) ?? navItems.value[0]!;
});

/** 页眉中文名同步到浏览器标签：与 titleTemplate 拼成「运营分析 · Path Seeker 秘径寻踪」 */
useHead({
  title: computed(() => String(currentPage.value?.label || '控制台').trim() || '控制台'),
});

const openLogoutConfirm = () => {
  logoutConfirmOpen.value = true;
};

const handleLogout = async () => {
  if (loggingOut.value) {
    return;
  }
  loggingOut.value = true;
  try {
    logoutConfirmOpen.value = false;
    authStore.logout();
    await nextTick();
    await navigateTo(ADMIN_LOGIN_PATH, { replace: true });
  } finally {
    loggingOut.value = false;
  }
};
</script>

<template>
  <header class="border-b border-border bg-background/96 backdrop-blur-sm">
    <div class="admin-topbar-inner flex items-center justify-between gap-3 px-3 sm:px-5 lg:px-6">
      <div class="flex min-w-0 items-center gap-2 sm:gap-3">
        <!-- 窄屏侧栏隐藏后，由此打开导航抽屉 -->
        <button
          type="button"
          class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-white/8 hover:text-foreground lg:hidden"
          title="打开导航菜单"
          aria-label="打开导航菜单"
          :aria-expanded="open"
          aria-controls="admin-nav-drawer"
          @click="openNav"
        >
          <UiAppIcon name="menu" class="h-4 w-4" />
        </button>
        <div class="flex min-w-0 items-center">
          <p class="font-display truncate text-[1.1rem] font-semibold tracking-tight text-primary sm:text-[1.18rem]">Path Seeker</p>
        </div>
        <div class="hidden h-5 w-px bg-border sm:block" />
        <div class="min-w-0">
          <p class="hidden text-[11px] uppercase tracking-[0.24em] text-primary/80 sm:block">path seeker museum</p>
          <h1 class="truncate text-base font-semibold text-foreground sm:pt-1">{{ currentPage?.label || '控制台' }}</h1>
        </div>
      </div>

      <div class="flex items-center gap-3 text-sm text-foreground">
        <!-- 平台助手入口（设计文档 §8）：全部后台账号可用，与页面内 Chat 会话隔离 -->
        <UiButton
          variant="ghost"
          size="sm"
          class="gap-1.5 text-muted-foreground hover:text-foreground"
          title="打开平台助手（与页面内对话隔离）"
          aria-label="打开平台助手"
          :aria-expanded="assistantOpen"
          aria-controls="platform-assistant-drawer"
          @click="openAssistant()">
          <UiAppIcon name="sparkles" class="h-4 w-4" />
          <span class="hidden md:inline">平台助手</span>
        </UiButton>
        <UiButton
          variant="ghost"
          size="sm"
          class="gap-1.5 text-muted-foreground hover:text-foreground"
          title="打开菜单提示"
          aria-label="打开菜单提示"
          @click="openTips()">
          <UiAppIcon name="circle-help" class="h-4 w-4" />
          <span class="hidden md:inline">使用提示</span>
        </UiButton>
        <div class="flex h-8 w-8 items-center justify-center rounded-full bg-primary/14 text-primary ring-1 ring-inset ring-primary/20">
          <UiAppIcon name="user-round" class="h-4 w-4" />
        </div>
        <div class="hidden text-right sm:block">
          <p class="font-medium">{{ authStore.displayName }}</p>
          <p class="text-xs text-muted-foreground">{{ authStore.profile?.role || '管理员控制台' }}</p>
        </div>
        <UiButton variant="ghost" size="sm" @click="openLogoutConfirm">
          退出
        </UiButton>
      </div>
    </div>
  </header>

  <Dialog v-model:open="logoutConfirmOpen">
    <DialogContent class="max-w-[min(92vw,24rem)] rounded-xl border border-border bg-[#15171b] p-0 text-left">
      <DialogHeader class="space-y-2 px-5 pb-2 pt-4">
        <DialogTitle class="text-base font-semibold text-foreground">
          确认退出
        </DialogTitle>
        <DialogDescription class="text-sm leading-6 text-muted-foreground">
          退出后需重新登录才能进入控制台。确定要退出当前账号吗？
        </DialogDescription>
      </DialogHeader>
      <DialogFooter class="gap-2 px-5 pb-4 pt-3">
        <Button variant="outline" type="button" :disabled="loggingOut" @click="logoutConfirmOpen = false">
          取消
        </Button>
        <Button type="button" :disabled="loggingOut" @click="handleLogout">
          {{ loggingOut ? '退出中…' : '确认退出' }}
        </Button>
      </DialogFooter>
    </DialogContent>
  </Dialog>
</template>
