import { computed, shallowRef, watch } from 'vue';
import { v4 as uuidv4 } from 'uuid';
import { useApiClient } from '@/composables/useApiClient';
import type {
  CreateFloorPayload,
  CreateGalleryPayload,
  FloorResponse,
  GalleryPageRequest,
  GalleryResponse,
  GalleryResponseListTotalPageResult,
  UpdateFloorPayload,
  UpdateGalleryPayload,
} from '@/types/museum';
import type { FloorMapDraft, FloorMapRecord, VenueDraft } from '@/types/map-management';

const DEFAULT_GALLERY_CATEGORY = 1;
const DEFAULT_OPEN_STATUS = 1;

const isObjectRecord = (value: unknown): value is Record<string, unknown> =>
  Boolean(value && typeof value === 'object');

const normalizeList = <T>(value: unknown): T[] =>
  Array.isArray(value) ? value.filter(isObjectRecord) as T[] : [];

const normalizePagedList = <T>(value: unknown) => {
  if (!isObjectRecord(value)) {
    return {
      list: [] as T[],
      pageIndex: 1,
      pageSize: 1000,
      total: 0,
      totalPages: 0,
    };
  }

  return {
    list: normalizeList<T>(value.list),
    pageIndex: typeof value.pageIndex === 'number' ? value.pageIndex : 1,
    pageSize: typeof value.pageSize === 'number' ? value.pageSize : 1000,
    total: typeof value.total === 'number' ? value.total : 0,
    totalPages: typeof value.totalPages === 'number' ? value.totalPages : 0,
  };
};

const createVenue = (): VenueDraft => ({
  id: uuidv4(),
  galleryCode: '',
  name: '',
  subtitle: '',
  category: DEFAULT_GALLERY_CATEGORY,
  description: '',
  exhibitCount: null,
  area: null,
  coverImageUrl: null,
  coverImageFileId: null,
  openStatus: DEFAULT_OPEN_STATUS,
  x: null,
  y: null,
  sortOrder: 0,
});

const toNullableId = (value: string | null | undefined) => {
  const normalized = String(value ?? '').trim();
  if (!normalized) {
    return null;
  }

  return normalized;
};

const normalizeVenue = (venue: VenueDraft, index: number): VenueDraft => ({
  ...venue,
  galleryCode: venue.galleryCode.trim(),
  name: venue.name.trim(),
  subtitle: venue.subtitle.trim(),
  description: venue.description.trim(),
  category: venue.category || DEFAULT_GALLERY_CATEGORY,
  openStatus: venue.openStatus || DEFAULT_OPEN_STATUS,
  sortOrder: venue.sortOrder || index + 1,
});

const normalizeDraft = (draft: FloorMapDraft): FloorMapDraft => ({
  id: draft.id,
  floorNumber: draft.floorNumber.trim(),
  floorName: draft.floorName.trim(),
  floorLevel: Number.isFinite(draft.floorLevel) ? draft.floorLevel : 0,
  description: draft.description.trim(),
  mapImages: draft.mapImages.filter(Boolean).slice(0, 1),
  mapImageFileId: draft.mapImageFileId,
  sortOrder: Number.isFinite(draft.sortOrder) ? draft.sortOrder : 0,
  venues: draft.venues
    .map(normalizeVenue)
    .filter((venue) => venue.galleryCode || venue.name || venue.x !== null || venue.y !== null),
});

export const useMapManagement = () => {
  const runtimeConfig = useRuntimeConfig();
  const museumId = computed(() => String(runtimeConfig.public.museumId || '1').trim());
  const { request } = useApiClient();

  const createEmptyDraft = (): FloorMapDraft => ({
    floorNumber: '',
    floorName: '',
    floorLevel: 0,
    description: '',
    mapImages: [],
    mapImageFileId: null,
    sortOrder: 0,
    venues: [createVenue()],
  });

  const data = shallowRef<{ floors: FloorResponse[]; galleries: GalleryResponse[] }>({ floors: [], galleries: [] });
  const pending = shallowRef(false);
  const error = shallowRef<Error | null>(null);
  let requestVersion = 0;

  const refresh = async () => {
    const currentVersion = ++requestVersion;
    const currentMuseumId = museumId.value;
    pending.value = true;
    error.value = null;
    try {
      const [floors, galleries] = await Promise.all([
        request<FloorResponse[]>('/api/map-management/floors', {
          query: { museumId: currentMuseumId },
        }),
        request<GalleryResponseListTotalPageResult<GalleryResponse>>('/api/map-management/galleries/query', {
          method: 'POST',
          body: {
            pageIndex: 1,
            pageSize: 1000,
            museumId: currentMuseumId,
          } satisfies GalleryPageRequest,
        }),
      ]);
      if (currentVersion !== requestVersion) return;
      data.value = {
        floors: Array.isArray(floors) ? normalizeList<FloorResponse>(floors) : normalizePagedList<FloorResponse>(floors).list,
        galleries: galleries.list ?? [],
      };
    } catch (caught) {
      if (currentVersion !== requestVersion) return;
      error.value = caught instanceof Error ? caught : new Error('地图数据加载失败。');
    } finally {
      if (currentVersion === requestVersion) pending.value = false;
    }
  };

  watch(museumId, () => {
    if (import.meta.client) void refresh();
  }, { immediate: true });

  const maps = computed<FloorMapRecord[]>(() => {
    const galleriesByFloorId = new Map<string, GalleryResponse[]>();

    for (const gallery of data.value.galleries) {
      if (!gallery.floorId) {
        continue;
      }

      const floorGalleries = galleriesByFloorId.get(gallery.floorId) ?? [];
      floorGalleries.push(gallery);
      galleriesByFloorId.set(gallery.floorId, floorGalleries);
    }

    return data.value.floors.map((floor) => {
      const floorId = floor.id ?? uuidv4();
      const galleries = (galleriesByFloorId.get(floorId) ?? [])
        .slice()
        .sort((left, right) => (left.sortOrder ?? 0) - (right.sortOrder ?? 0));

      return {
        id: floorId,
        floorNumber: floor.floorCode ?? '',
        floorName: floor.floorName ?? '',
        floorLevel: floor.floorLevel ?? 0,
        description: floor.description ?? '',
        mapImages: floor.mapImageUrl ? [floor.mapImageUrl] : [],
        mapImageFileId: toNullableId(floor.mapImageUrl),
        sortOrder: floor.sortOrder ?? 0,
        venues: galleries.map((gallery, index) => ({
          id: gallery.id ?? uuidv4(),
          galleryCode: gallery.galleryCode ?? '',
          name: gallery.name ?? '',
          subtitle: gallery.subtitle ?? '',
          category: gallery.category ?? DEFAULT_GALLERY_CATEGORY,
          description: gallery.description ?? '',
          exhibitCount: gallery.exhibitCount,
          area: gallery.area,
          coverImageUrl: gallery.coverImageUrl,
          coverImageFileId: toNullableId(gallery.coverImageUrl),
          openStatus: gallery.openStatus ?? DEFAULT_OPEN_STATUS,
          x: gallery.x,
          y: gallery.y,
          sortOrder: gallery.sortOrder ?? index + 1,
        })),
        includedVenueNames: galleries.map((gallery) => gallery.name ?? '').filter(Boolean),
      };
    });
  });

  const createDraftFromRecord = (record: FloorMapRecord): FloorMapDraft => ({
    id: record.id,
    floorNumber: record.floorNumber,
    floorName: record.floorName,
    floorLevel: record.floorLevel,
    description: record.description,
    mapImages: [...record.mapImages],
    mapImageFileId: record.mapImageFileId,
    sortOrder: record.sortOrder,
    venues: record.venues.map((venue) => ({ ...venue })),
  });

  const saveGalleries = async (floorId: string, draft: FloorMapDraft) => {
    const existingGalleryIds = new Set(
      data.value.galleries
        .filter((gallery) => gallery.floorId === floorId)
        .map((gallery) => gallery.id)
        .filter((id): id is string => Boolean(id))
    );
    const nextGalleryIds = new Set(
      draft.venues.filter((venue) => /^\d+$/.test(venue.id)).map((venue) => venue.id)
    );

    for (const gallery of draft.venues.map(normalizeVenue)) {
      const basePayload: CreateGalleryPayload = {
        museumId: museumId.value,
        floorId,
        galleryCode: gallery.galleryCode || `G-${draft.floorNumber}-${gallery.sortOrder}`,
        name: gallery.name || `未命名展厅 ${gallery.sortOrder}`,
        subtitle: gallery.subtitle || null,
        category: gallery.category,
        description: gallery.description || null,
        exhibitCount: gallery.exhibitCount,
        area: gallery.area,
        coverImageUrl: toNullableId(gallery.coverImageFileId),
        openStatus: gallery.openStatus,
        x: gallery.x,
        y: gallery.y,
        sortOrder: gallery.sortOrder,
      };

      if (/^\d+$/.test(gallery.id)) {
        await request('/api/map-management/galleries/' + gallery.id, {
          method: 'PUT',
          body: {
            ...basePayload,
            id: gallery.id,
          } satisfies UpdateGalleryPayload,
        });
        continue;
      }

      await request<string>('/api/map-management/galleries', {
        method: 'POST',
        body: basePayload,
      });
    }

    for (const galleryId of existingGalleryIds) {
      if (nextGalleryIds.has(galleryId)) {
        continue;
      }

      await request('/api/map-management/galleries/' + galleryId, {
        method: 'DELETE',
      });
    }
  };

  const saveDraft = async (draft: FloorMapDraft, targetId?: string) => {
    const normalized = normalizeDraft(draft);
    const baseFloorPayload: CreateFloorPayload = {
      museumId: museumId.value,
      floorCode: normalized.floorNumber,
      floorName: normalized.floorName || null,
      floorLevel: normalized.floorLevel,
      description: normalized.description || null,
      mapImageUrl: toNullableId(normalized.mapImages[0] ?? null),
      sortOrder: normalized.sortOrder,
    };

    let floorId = targetId ?? normalized.id ?? '';

    if (targetId) {
      await request('/api/map-management/floors/' + targetId, {
        method: 'PUT',
        body: {
          ...baseFloorPayload,
          id: targetId,
        } satisfies UpdateFloorPayload,
      });
    } else {
      floorId = await request<string>('/api/map-management/floors', {
        method: 'POST',
        body: baseFloorPayload,
      });
    }

    await saveGalleries(floorId, normalized);
    await refresh();
  };

  const deleteMap = async (targetId: string) => {
    const floorGalleries = data.value.galleries.filter((gallery) => gallery.floorId === targetId);

    for (const gallery of floorGalleries) {
      if (!gallery.id) {
        continue;
      }

      await request('/api/map-management/galleries/' + gallery.id, {
        method: 'DELETE',
      });
    }

    await request('/api/map-management/floors/' + targetId, {
      method: 'DELETE',
    });
    await refresh();
  };

  return {
    maps,
    pending,
    error,
    refresh,
    createEmptyDraft,
    createDraftFromRecord,
    saveDraft,
    deleteMap,
  };
};

