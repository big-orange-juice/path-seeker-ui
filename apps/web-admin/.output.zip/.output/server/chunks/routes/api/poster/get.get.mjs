import { c as defineEventHandler, h as getQuery, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const get_get = defineEventHandler(async (event) => {
  var _a, _b;
  const id = String((_a = getQuery(event).id) != null ? _a : "").trim();
  if (!id) throw createError({ statusCode: 400, message: "\u7F3A\u5C11\u6D77\u62A5\u6807\u8BC6\u3002" });
  const response = await backendFetch(event, "/Poster/Get", {
    method: "GET",
    query: { id }
  });
  return (_b = unwrapApiResponse(response)) != null ? _b : null;
});

export { get_get as default };
//# sourceMappingURL=get.get.mjs.map
