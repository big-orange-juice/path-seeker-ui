import { c as defineEventHandler, h as getQuery, g as createError, p as resolveHttpStatusMessage } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const styleReferenceFileContent_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const rawUrl = String(query.url || "").trim();
  if (!rawUrl) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u6587\u4EF6\u5730\u5740\u3002"
    });
  }
  let target;
  try {
    target = new URL(rawUrl);
  } catch {
    throw createError({
      statusCode: 400,
      message: "\u6587\u4EF6\u5730\u5740\u65E0\u6548\u3002"
    });
  }
  if (target.protocol !== "http:" && target.protocol !== "https:") {
    throw createError({
      statusCode: 400,
      message: "\u4EC5\u652F\u6301 http/https \u6587\u4EF6\u5730\u5740\u3002"
    });
  }
  const upstream = await fetch(target, {
    method: "GET",
    headers: {
      accept: "text/plain,text/*,application/json,application/octet-stream,*/*"
    }
  });
  if (!upstream.ok) {
    const statusCode = upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502;
    throw createError({
      statusCode,
      message: resolveHttpStatusMessage(statusCode, "\u98CE\u683C\u53C2\u8003\u6587\u4EF6\u8BFB\u53D6\u5931\u8D25\u3002")
    });
  }
  const buffer = Buffer.from(await upstream.arrayBuffer());
  const text = buffer.toString("utf8").replace(/^\uFEFF/, "");
  return { text };
});

export { styleReferenceFileContent_get as default };
//# sourceMappingURL=style-reference-file-content.get.mjs.map
