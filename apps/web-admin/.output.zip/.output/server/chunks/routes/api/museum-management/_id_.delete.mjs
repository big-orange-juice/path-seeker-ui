import { d as defineEventHandler, j as getRouterParam, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const _id__delete = defineEventHandler(async (event) => {
  const id = String(getRouterParam(event, "id") || "").trim();
  const response = await backendFetch(event, "/api/Museum/Delete", {
    method: "POST",
    body: { id }
  });
  return unwrapApiResponse(response);
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
