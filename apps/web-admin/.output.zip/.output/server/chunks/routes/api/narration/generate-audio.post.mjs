import { d as defineEventHandler, r as readBody, c as createError, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const generateAudio_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const stageId = String((_a = body == null ? void 0 : body.stageId) != null ? _a : "").trim();
  if (!stageId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8282\u70B9 ID\u3002"
    });
  }
  const response = await backendFetch(event, "/api/Narration/generate-audio", {
    method: "POST",
    body: {
      stageId
    }
  });
  return unwrapApiResponse(response);
});

export { generateAudio_post as default };
//# sourceMappingURL=generate-audio.post.mjs.map
