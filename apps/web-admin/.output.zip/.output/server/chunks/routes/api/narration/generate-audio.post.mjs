import { c as defineEventHandler, r as readBody, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const generateAudio_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const stageId = String((_a = body == null ? void 0 : body.stageId) != null ? _a : "").trim();
  if (!stageId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8282\u70B9 ID\u3002"
    });
  }
  const response = await backendFetch(event, "/Narration/generate-audio", {
    method: "POST",
    body: {
      stageId
    }
  });
  return unwrapApiResponse(response);
});

export { generateAudio_post as default };
//# sourceMappingURL=generate-audio.post.mjs.map
