import { c as defineEventHandler, f as unwrapApiResponse, e as backendFetch, r as readBody } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const update_post = defineEventHandler(async (event) => unwrapApiResponse(await backendFetch(event, "/Tag/Update", { method: "POST", body: await readBody(event) })));

export { update_post as default };
//# sourceMappingURL=update.post.mjs.map
