import { d as defineEventHandler, r as readBody, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const update_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(event, "/api/Guide/update", {
    method: "POST",
    body
  });
  return unwrapApiResponse(response);
});

export { update_post as default };
//# sourceMappingURL=update.post.mjs.map
