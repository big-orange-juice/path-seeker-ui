import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const _id__put = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(event, "/Exhibit/Update", {
    method: "POST",
    body
  });
  return unwrapApiResponse(response);
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
