import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const create_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const response = await backendFetch(event, "/Admin/CreateAdmin", {
    method: "POST",
    body: {
      username: String((body == null ? void 0 : body.username) || "").trim(),
      password: String((body == null ? void 0 : body.password) || ""),
      realName: String((body == null ? void 0 : body.realName) || "").trim() || null,
      phone: String((body == null ? void 0 : body.phone) || "").trim() || null,
      email: String((body == null ? void 0 : body.email) || "").trim() || null,
      roleId: String((body == null ? void 0 : body.roleId) || "").trim()
    }
  });
  return String((_a = unwrapApiResponse(response)) != null ? _a : "");
});

export { create_post as default };
//# sourceMappingURL=create.post.mjs.map
