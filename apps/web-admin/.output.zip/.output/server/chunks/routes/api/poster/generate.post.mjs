import { c as defineEventHandler, r as readBody, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const generate_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const body = await readBody(event);
  const routeId = String((_a = body == null ? void 0 : body.routeId) != null ? _a : "").trim();
  const prompt = String((_b = body == null ? void 0 : body.prompt) != null ? _b : "").trim();
  if (!routeId || !prompt) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8DEF\u7EBF\u6216\u753B\u9762\u63CF\u8FF0\u3002"
    });
  }
  if (prompt.length > 4e3) {
    throw createError({
      statusCode: 400,
      message: "\u753B\u9762\u63CF\u8FF0\u8FC7\u957F\uFF0C\u8BF7\u7CBE\u7B80\u540E\u518D\u8BD5\u3002"
    });
  }
  const referenceImageUrls = Array.isArray(body == null ? void 0 : body.referenceImageUrls) ? body.referenceImageUrls.map((item) => String(item != null ? item : "").trim()).filter((item) => item.length > 0).slice(0, 5) : [];
  const payload = {
    routeId,
    prompt,
    priority: 1e4
  };
  if (referenceImageUrls.length) {
    payload.referenceImageUrls = referenceImageUrls;
  }
  const response = await backendFetch(
    event,
    "/Poster/Generate",
    {
      method: "POST",
      body: payload
    }
  );
  return (_c = unwrapApiResponse(response)) != null ? _c : null;
});

export { generate_post as default };
//# sourceMappingURL=generate.post.mjs.map
