import { c as defineEventHandler, r as readBody, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const stageCreate_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const routeId = String((_a = body == null ? void 0 : body.routeId) != null ? _a : "").trim();
  if (!routeId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8DEF\u7EBF ID\u3002"
    });
  }
  const response = await backendFetch(event, "/Gameplay/StageCreate", {
    method: "POST",
    body: {
      ...body,
      routeId,
      refPuzzleId: (body == null ? void 0 : body.refPuzzleId) != null ? String(body.refPuzzleId) : null,
      refExhibitId: (body == null ? void 0 : body.refExhibitId) != null ? String(body.refExhibitId) : null
    }
  });
  return unwrapApiResponse(response);
});

export { stageCreate_post as default };
//# sourceMappingURL=stage-create.post.mjs.map
