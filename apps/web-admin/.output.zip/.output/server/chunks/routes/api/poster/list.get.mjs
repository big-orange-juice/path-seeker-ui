import { c as defineEventHandler, h as getQuery, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const list_get = defineEventHandler(async (event) => {
  var _a;
  const query = getQuery(event);
  const routeId = String((_a = query.routeId) != null ? _a : "").trim();
  if (!routeId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8DEF\u7EBF\u6807\u8BC6\u3002"
    });
  }
  const response = await backendFetch(
    event,
    "/Route/Posters",
    {
      method: "GET",
      query: { routeId }
    }
  );
  const data = unwrapApiResponse(response);
  return Array.isArray(data) ? data : [];
});

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
