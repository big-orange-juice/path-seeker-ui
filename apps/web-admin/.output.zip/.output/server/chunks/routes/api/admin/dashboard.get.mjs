import { c as defineEventHandler, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const emptyDashboard = () => ({
  overview: null,
  routeStats: [],
  ageDistribution: [],
  stuckPuzzles: [],
  hotExhibits: []
});
const dashboard_get = defineEventHandler(async (event) => {
  var _a;
  const response = await backendFetch(event, "/Admin/Dashboard", {
    method: "GET"
  });
  const data = unwrapApiResponse(response);
  if (!data) {
    return emptyDashboard();
  }
  return {
    overview: (_a = data.overview) != null ? _a : null,
    routeStats: Array.isArray(data.routeStats) ? data.routeStats.map((item) => {
      var _a2;
      return {
        ...item,
        routeId: String((_a2 = item.routeId) != null ? _a2 : "")
      };
    }) : [],
    ageDistribution: Array.isArray(data.ageDistribution) ? data.ageDistribution : [],
    stuckPuzzles: Array.isArray(data.stuckPuzzles) ? data.stuckPuzzles.map((item) => {
      var _a2;
      return {
        ...item,
        puzzleId: String((_a2 = item.puzzleId) != null ? _a2 : "")
      };
    }) : [],
    hotExhibits: Array.isArray(data.hotExhibits) ? data.hotExhibits.map((item) => {
      var _a2;
      return {
        ...item,
        exhibitId: String((_a2 = item.exhibitId) != null ? _a2 : "")
      };
    }) : []
  };
});

export { dashboard_get as default };
//# sourceMappingURL=dashboard.get.mjs.map
