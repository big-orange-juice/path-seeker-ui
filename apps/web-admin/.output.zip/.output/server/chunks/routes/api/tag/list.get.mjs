import { c as defineEventHandler, h as getQuery, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const list_get = defineEventHandler(async (event) => {
  var _a, _b;
  const category = String((_a = getQuery(event).category) != null ? _a : "").trim();
  const response = await backendFetch(event, "/Tag/List", { query: { category: category || void 0 } });
  return (_b = unwrapApiResponse(response)) != null ? _b : [];
});

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
