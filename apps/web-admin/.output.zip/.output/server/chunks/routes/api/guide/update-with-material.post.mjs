import { d as defineEventHandler, k as readFormData, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const updateWithMaterial_post = defineEventHandler(async (event) => {
  var _a;
  const formData = await readFormData(event);
  const response = await backendFetch(
    event,
    "/api/Guide/update-with-material",
    {
      method: "POST",
      body: formData
    }
  );
  return (_a = unwrapApiResponse(response)) != null ? _a : null;
});

export { updateWithMaterial_post as default };
//# sourceMappingURL=update-with-material.post.mjs.map
