import { c as defineEventHandler, h as getQuery, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const detail_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const id = String(query.id || "").trim();
  if (!id) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u5BFC\u6E38 ID\u3002"
    });
  }
  const response = await backendFetch(event, "/Guide/detail", {
    query: { id }
  });
  return unwrapApiResponse(response);
});

export { detail_get as default };
//# sourceMappingURL=detail.get.mjs.map
