import { d as defineEventHandler, r as readBody, c as createError, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const updateStage_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const stageId = String((_a = body == null ? void 0 : body.stageId) != null ? _a : "").trim();
  if (!stageId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8282\u70B9 ID\u3002"
    });
  }
  const payload = {
    stageId
  };
  if ((body == null ? void 0 : body.title) !== void 0) {
    payload.title = body.title == null ? null : String(body.title);
  }
  if ((body == null ? void 0 : body.subtitle) !== void 0) {
    payload.subtitle = body.subtitle == null ? null : String(body.subtitle);
  }
  if ((body == null ? void 0 : body.exhibitId) !== void 0) {
    payload.exhibitId = body.exhibitId == null ? null : String(body.exhibitId).trim() || null;
  }
  if ((body == null ? void 0 : body.guideId) !== void 0) {
    payload.guideId = body.guideId == null ? null : String(body.guideId).trim() || null;
  }
  if ((body == null ? void 0 : body.userStyleInput) !== void 0) {
    payload.userStyleInput = body.userStyleInput == null ? null : String(body.userStyleInput);
  }
  if ((body == null ? void 0 : body.sceneContext) !== void 0) {
    payload.sceneContext = body.sceneContext == null ? null : String(body.sceneContext);
  }
  if ((body == null ? void 0 : body.targetDurationSeconds) !== void 0 && body.targetDurationSeconds !== null && Number.isFinite(Number(body.targetDurationSeconds))) {
    const sec = Math.trunc(Number(body.targetDurationSeconds));
    payload.targetDurationSeconds = Math.min(600, Math.max(10, sec));
  }
  if (body == null ? void 0 : body.expectedUpdatedAt) {
    payload.expectedUpdatedAt = String(body.expectedUpdatedAt);
  }
  const response = await backendFetch(
    event,
    "/api/Narration/update-stage",
    {
      method: "POST",
      body: payload
    }
  );
  return (_b = unwrapApiResponse(response)) != null ? _b : null;
});

export { updateStage_post as default };
//# sourceMappingURL=update-stage.post.mjs.map
