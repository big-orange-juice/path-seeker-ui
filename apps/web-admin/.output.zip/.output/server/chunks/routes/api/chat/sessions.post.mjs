import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const sessions_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const response = await backendFetch(event, "/Chat/sessions", {
    method: "POST",
    body: {
      title: (_a = body == null ? void 0 : body.title) != null ? _a : null,
      contextRouteId: (_b = body == null ? void 0 : body.contextRouteId) != null ? _b : null
    }
  });
  return unwrapApiResponse(response);
});

export { sessions_post as default };
//# sourceMappingURL=sessions.post.mjs.map
