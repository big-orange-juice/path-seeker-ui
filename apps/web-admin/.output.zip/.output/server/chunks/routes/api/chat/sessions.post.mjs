import { d as defineEventHandler, r as readBody, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const sessions_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const response = await backendFetch(event, "/api/Chat/sessions", {
    method: "POST",
    body: {
      title: (_a = body == null ? void 0 : body.title) != null ? _a : null,
      contextRouteId: (_b = body == null ? void 0 : body.contextRouteId) != null ? _b : null
    }
  });
  return unwrapApiResponse(response);
});

export { sessions_post as default };
//# sourceMappingURL=sessions.post.mjs.map
