import { d as defineEventHandler, r as readBody, b as backendFetch, u as unwrapApiResponse } from '../../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const _id__put = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(event, "/api/Museum/UpdateFacility", {
    method: "POST",
    body
  });
  return unwrapApiResponse(response);
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
