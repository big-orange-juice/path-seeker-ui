import { d as defineEventHandler, g as getQuery, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const list_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const keyword = String(query.keyword || query.Keyword || "").trim();
  const voiceType = String(query.voiceType || query.VoiceType || "").trim();
  const response = await backendFetch(
    event,
    "/api/TtsVoice/list",
    {
      query: {
        Keyword: keyword || void 0,
        VoiceType: voiceType || void 0
      }
    }
  );
  const data = unwrapApiResponse(response);
  return Array.isArray(data) ? data : [];
});

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
