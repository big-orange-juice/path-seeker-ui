import { c as defineEventHandler, h as getQuery, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const list_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const keyword = String(query.keyword || query.Keyword || "").trim();
  const voiceType = String(query.voiceType || query.VoiceType || "").trim();
  const response = await backendFetch(
    event,
    "/TtsVoice/list",
    {
      query: {
        Keyword: keyword || void 0,
        VoiceType: voiceType || void 0
      }
    }
  );
  const data = unwrapApiResponse(response);
  return Array.isArray(data) ? data : [];
});

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
