import { d as defineEventHandler, g as getQuery, c as createError, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const detail_get = defineEventHandler(async (event) => {
  var _a, _b;
  const query = getQuery(event);
  const stageId = String((_a = query.stageId) != null ? _a : "").trim();
  if (!stageId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8282\u70B9 ID\u3002"
    });
  }
  const response = await backendFetch(event, "/api/Narration/detail", {
    method: "GET",
    query: {
      stageId
    }
  });
  return (_b = unwrapApiResponse(response)) != null ? _b : null;
});

export { detail_get as default };
//# sourceMappingURL=detail.get.mjs.map
