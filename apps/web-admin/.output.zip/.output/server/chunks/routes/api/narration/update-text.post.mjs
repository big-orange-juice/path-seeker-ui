import { d as defineEventHandler, r as readBody, c as createError, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const updateText_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const body = await readBody(event);
  const stageId = String((_a = body == null ? void 0 : body.stageId) != null ? _a : "").trim();
  const narrationText = String((_b = body == null ? void 0 : body.narrationText) != null ? _b : "").trim();
  if (!stageId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8282\u70B9 ID\u3002"
    });
  }
  if (!narrationText) {
    throw createError({
      statusCode: 400,
      message: "\u89E3\u8BF4\u8BCD\u4E0D\u80FD\u4E3A\u7A7A\u3002"
    });
  }
  const payload = {
    stageId,
    narrationText
  };
  if (typeof (body == null ? void 0 : body.version) === "number" && Number.isFinite(body.version) && body.version >= 1) {
    payload.version = Math.trunc(body.version);
  }
  const response = await backendFetch(
    event,
    "/api/Narration/update-text",
    {
      method: "POST",
      body: payload
    }
  );
  return (_c = unwrapApiResponse(response)) != null ? _c : null;
});

export { updateText_post as default };
//# sourceMappingURL=update-text.post.mjs.map
