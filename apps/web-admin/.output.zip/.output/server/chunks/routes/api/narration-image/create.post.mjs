import { c as defineEventHandler, r as readBody, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const create_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const body = await readBody(event);
  const stageId = String((_a = body == null ? void 0 : body.stageId) != null ? _a : "").trim();
  const attachmentId = String((_b = body == null ? void 0 : body.attachmentId) != null ? _b : "").trim();
  if (!stageId || !attachmentId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8282\u70B9\u6216\u9644\u4EF6\u4FE1\u606F\u3002"
    });
  }
  const payload = {
    stageId,
    attachmentId
  };
  if (typeof (body == null ? void 0 : body.sortOrder) === "number" && Number.isFinite(body.sortOrder)) {
    payload.sortOrder = Math.max(0, Math.round(body.sortOrder));
  }
  const response = await backendFetch(event, "/NarrationImage/create", {
    method: "POST",
    body: payload
  });
  return (_c = unwrapApiResponse(response)) != null ? _c : null;
});

export { create_post as default };
//# sourceMappingURL=create.post.mjs.map
