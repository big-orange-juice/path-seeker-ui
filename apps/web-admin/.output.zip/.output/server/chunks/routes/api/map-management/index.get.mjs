import { d as defineEventHandler, g as getQuery, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const query = getQuery(event);
  const museumId = String(query.museumId || "").trim();
  const response = await backendFetch(event, "/api/Museum/Floors", {
    query: { museumId }
  });
  return (_a = unwrapApiResponse(response)) != null ? _a : [];
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
