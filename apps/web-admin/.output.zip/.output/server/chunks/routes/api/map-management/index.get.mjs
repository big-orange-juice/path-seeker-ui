import { c as defineEventHandler, h as getQuery, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const query = getQuery(event);
  const museumId = String(query.museumId || "").trim();
  const response = await backendFetch(event, "/Museum/Floors", {
    query: { museumId }
  });
  return (_a = unwrapApiResponse(response)) != null ? _a : [];
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
