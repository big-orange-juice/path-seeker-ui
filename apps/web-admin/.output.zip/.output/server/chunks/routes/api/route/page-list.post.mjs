import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const resolveList = (payload) => {
  var _a, _b, _c;
  const source = payload && typeof payload === "object" ? payload : {};
  const candidate = (_c = (_b = (_a = source.list) != null ? _a : source.items) != null ? _b : source.records) != null ? _c : [];
  if (Array.isArray(candidate)) {
    return candidate;
  }
  if (candidate && typeof candidate === "object" && Array.isArray(candidate.$values)) {
    return candidate.$values;
  }
  return [];
};
const resolveNumber = (value, fallback) => {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
};
const pageList_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(
    event,
    "/Route/PageList",
    {
      method: "POST",
      body
    }
  );
  const data = unwrapApiResponse(response);
  return {
    list: resolveList(data),
    pageIndex: resolveNumber(data == null ? void 0 : data.pageIndex, body.pageIndex || 1),
    pageSize: resolveNumber(data == null ? void 0 : data.pageSize, body.pageSize || 10),
    total: resolveNumber(data == null ? void 0 : data.total, 0),
    totalPages: resolveNumber(data == null ? void 0 : data.totalPages, 0)
  };
});

export { pageList_post as default };
//# sourceMappingURL=page-list.post.mjs.map
