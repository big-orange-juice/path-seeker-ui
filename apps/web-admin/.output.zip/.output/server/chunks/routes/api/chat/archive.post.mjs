import { d as defineEventHandler, r as readBody, c as createError, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const archive_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const id = String((_a = body == null ? void 0 : body.id) != null ? _a : "").trim();
  if (!id) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u4F1A\u8BDD ID\u3002"
    });
  }
  const response = await backendFetch(event, "/api/Chat/archive", {
    method: "POST",
    body: { id }
  });
  return unwrapApiResponse(response);
});

export { archive_post as default };
//# sourceMappingURL=archive.post.mjs.map
