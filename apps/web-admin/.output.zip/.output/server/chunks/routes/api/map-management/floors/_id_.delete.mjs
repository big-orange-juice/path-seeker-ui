import { c as defineEventHandler, n as getRouterParam, e as backendFetch, f as unwrapApiResponse } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const _id__delete = defineEventHandler(async (event) => {
  const id = String(getRouterParam(event, "id") || "").trim();
  const response = await backendFetch(event, "/Museum/DeleteFloor", {
    method: "POST",
    body: { id }
  });
  return unwrapApiResponse(response);
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
