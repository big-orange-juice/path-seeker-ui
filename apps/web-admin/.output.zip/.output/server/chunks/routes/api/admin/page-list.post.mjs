import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const pageList_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const body = await readBody(event);
  const pageIndex = Math.max(1, Number((body == null ? void 0 : body.pageIndex) || 1) || 1);
  const pageSize = Math.max(1, Number((body == null ? void 0 : body.pageSize) || 10) || 10);
  const keyword = String((body == null ? void 0 : body.keyword) || "").trim();
  const roleId = String((body == null ? void 0 : body.roleId) || "").trim();
  const statusRaw = body == null ? void 0 : body.status;
  const response = await backendFetch(event, "/Admin/PageList", {
    method: "POST",
    body: {
      pageIndex,
      pageSize,
      keyword: keyword || null,
      roleId: roleId || null,
      status: statusRaw === null || statusRaw === void 0 || Number(statusRaw) === 0 ? null : Number(statusRaw)
    }
  });
  const data = unwrapApiResponse(response);
  return {
    list: ((_a = data == null ? void 0 : data.list) != null ? _a : []).map((item) => {
      var _a2, _b2;
      return {
        ...item,
        id: String((_a2 = item.id) != null ? _a2 : ""),
        roleId: String((_b2 = item.roleId) != null ? _b2 : "")
      };
    }),
    pageIndex: (_b = data == null ? void 0 : data.pageIndex) != null ? _b : pageIndex,
    pageSize: (_c = data == null ? void 0 : data.pageSize) != null ? _c : pageSize,
    total: (_d = data == null ? void 0 : data.total) != null ? _d : 0,
    totalPages: (_e = data == null ? void 0 : data.totalPages) != null ? _e : 0
  };
});

export { pageList_post as default };
//# sourceMappingURL=page-list.post.mjs.map
