import { c as defineEventHandler, r as readBody, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const update_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const body = await readBody(event);
  const id = String((_a = body == null ? void 0 : body.id) != null ? _a : "").trim();
  const routeCode = String((_b = body == null ? void 0 : body.routeCode) != null ? _b : "").trim();
  const title = String((_c = body == null ? void 0 : body.title) != null ? _c : "").trim();
  if (!id || !routeCode || !title) {
    throw createError({
      statusCode: 400,
      message: "\u8DEF\u7EBF ID\u3001\u7F16\u7801\u548C\u6807\u9898\u4E0D\u80FD\u4E3A\u7A7A\u3002"
    });
  }
  const response = await backendFetch(event, "/Route/Update", {
    method: "POST",
    body: { id, routeCode, title }
  });
  return unwrapApiResponse(response);
});

export { update_post as default };
//# sourceMappingURL=update.post.mjs.map
