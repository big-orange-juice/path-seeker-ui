import { c as defineEventHandler, r as readBody, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const delete_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const id = String((body == null ? void 0 : body.id) || "").trim();
  if (!id) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u5BFC\u6E38 ID\u3002"
    });
  }
  const response = await backendFetch(event, "/Guide/delete", {
    method: "POST",
    body: {
      id,
      replacementGuideId: body.replacementGuideId ? String(body.replacementGuideId).trim() || null : null
    }
  });
  return unwrapApiResponse(response);
});

export { delete_post as default };
//# sourceMappingURL=delete.post.mjs.map
