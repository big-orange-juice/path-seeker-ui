import { d as defineEventHandler, k as readFormData, c as createError, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const image_post = defineEventHandler(async (event) => {
  const formData = await readFormData(event);
  const file = formData.get("file");
  if (!(file instanceof Blob)) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u4E0A\u4F20\u6587\u4EF6\u3002"
    });
  }
  const nextFormData = new FormData();
  nextFormData.append("file", file, file.name || "image");
  const response = await backendFetch(event, "/api/Upload/UploadImage", {
    method: "POST",
    body: nextFormData
  });
  return unwrapApiResponse(response);
});

export { image_post as default };
//# sourceMappingURL=image.post.mjs.map
