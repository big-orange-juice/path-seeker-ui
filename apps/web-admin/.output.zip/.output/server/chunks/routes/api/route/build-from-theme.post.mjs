import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const buildFromTheme_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(event, "/Agent/BuildRouteFromTheme", {
    method: "POST",
    body
  });
  return unwrapApiResponse(response);
});

export { buildFromTheme_post as default };
//# sourceMappingURL=build-from-theme.post.mjs.map
