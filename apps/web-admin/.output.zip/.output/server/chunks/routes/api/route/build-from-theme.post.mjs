import { d as defineEventHandler, r as readBody, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const buildFromTheme_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(event, "/api/Agent/BuildRouteFromTheme", {
    method: "POST",
    body
  });
  return unwrapApiResponse(response);
});

export { buildFromTheme_post as default };
//# sourceMappingURL=build-from-theme.post.mjs.map
