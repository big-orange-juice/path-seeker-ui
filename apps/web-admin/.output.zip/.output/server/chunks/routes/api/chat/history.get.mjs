import { c as defineEventHandler, h as getQuery, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const history_get = defineEventHandler(async (event) => {
  var _a, _b;
  const query = getQuery(event);
  const sessionId = String((_a = query.sessionId) != null ? _a : "").trim();
  if (!sessionId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u4F1A\u8BDD ID\u3002"
    });
  }
  const response = await backendFetch(event, "/Chat/history", {
    method: "GET",
    query: {
      sessionId
    }
  });
  return (_b = unwrapApiResponse(response)) != null ? _b : [];
});

export { history_get as default };
//# sourceMappingURL=history.get.mjs.map
