import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const softDelete_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(event, "/Admin/SoftDelete", {
    method: "POST",
    body: {
      adminId: String((body == null ? void 0 : body.adminId) || "").trim()
    }
  });
  unwrapApiResponse(response);
});

export { softDelete_post as default };
//# sourceMappingURL=soft-delete.post.mjs.map
