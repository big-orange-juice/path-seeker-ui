import { c as defineEventHandler, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const roles_get = defineEventHandler(async (event) => {
  const response = await backendFetch(event, "/Admin/Roles", {
    method: "GET"
  });
  const data = unwrapApiResponse(response);
  return (Array.isArray(data) ? data : []).map((item) => {
    var _a;
    return {
      ...item,
      id: String((_a = item.id) != null ? _a : ""),
      permissions: Array.isArray(item.permissions) ? item.permissions.map(String) : []
    };
  });
});

export { roles_get as default };
//# sourceMappingURL=roles.get.mjs.map
