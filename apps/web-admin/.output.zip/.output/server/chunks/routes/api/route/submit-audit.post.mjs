import { d as defineEventHandler, r as readBody, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const submitAudit_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(event, "/api/Route/SubmitAudit", {
    method: "POST",
    body
  });
  return unwrapApiResponse(response);
});

export { submitAudit_post as default };
//# sourceMappingURL=submit-audit.post.mjs.map
