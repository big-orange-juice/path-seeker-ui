import { d as defineEventHandler, r as readBody, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const query_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const response = await backendFetch(
    event,
    "/api/Museum/PageList",
    {
      method: "POST",
      body
    }
  );
  return (_a = unwrapApiResponse(response)) != null ? _a : {
    list: [],
    pageIndex: body.pageIndex || 1,
    pageSize: body.pageSize || 10,
    total: 0,
    totalPages: 0
  };
});

export { query_post as default };
//# sourceMappingURL=query.post.mjs.map
