import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const query_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const response = await backendFetch(
    event,
    "/Museum/PageList",
    {
      method: "POST",
      body
    }
  );
  return (_a = unwrapApiResponse(response)) != null ? _a : {
    list: [],
    pageIndex: body.pageIndex || 1,
    pageSize: body.pageSize || 10,
    total: 0,
    totalPages: 0
  };
});

export { query_post as default };
//# sourceMappingURL=query.post.mjs.map
