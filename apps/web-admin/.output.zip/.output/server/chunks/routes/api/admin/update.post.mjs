import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const update_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(event, "/Admin/UpdateAdmin", {
    method: "POST",
    body: {
      id: String((body == null ? void 0 : body.id) || "").trim(),
      realName: String((body == null ? void 0 : body.realName) || "").trim() || null,
      phone: String((body == null ? void 0 : body.phone) || "").trim() || null,
      email: String((body == null ? void 0 : body.email) || "").trim() || null,
      roleId: String((body == null ? void 0 : body.roleId) || "").trim()
    }
  });
  unwrapApiResponse(response);
});

export { update_post as default };
//# sourceMappingURL=update.post.mjs.map
