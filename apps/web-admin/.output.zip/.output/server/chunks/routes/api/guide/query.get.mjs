import { c as defineEventHandler, h as getQuery, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const query_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g;
  const query = getQuery(event);
  const pageIndex = Math.max(1, Number(query.pageIndex || query.PageIndex || 1) || 1);
  const pageSize = Math.max(1, Number(query.pageSize || query.PageSize || 10) || 10);
  const keyword = String(query.keyword || query.Keyword || "").trim();
  const statusRaw = (_a = query.status) != null ? _a : query.Status;
  const voiceStatusRaw = (_b = query.voiceStatus) != null ? _b : query.VoiceStatus;
  const response = await backendFetch(
    event,
    "/Guide/list",
    {
      query: {
        Keyword: keyword || void 0,
        Status: statusRaw === null || statusRaw === void 0 || statusRaw === "" || Number(statusRaw) === 0 ? void 0 : Number(statusRaw),
        VoiceStatus: voiceStatusRaw === null || voiceStatusRaw === void 0 || voiceStatusRaw === "" || Number(voiceStatusRaw) === 0 ? void 0 : Number(voiceStatusRaw),
        PageIndex: pageIndex,
        PageSize: pageSize
      }
    }
  );
  const data = unwrapApiResponse(response);
  return {
    list: (_c = data == null ? void 0 : data.list) != null ? _c : [],
    pageIndex: (_d = data == null ? void 0 : data.pageIndex) != null ? _d : pageIndex,
    pageSize: (_e = data == null ? void 0 : data.pageSize) != null ? _e : pageSize,
    total: (_f = data == null ? void 0 : data.total) != null ? _f : 0,
    totalPages: (_g = data == null ? void 0 : data.totalPages) != null ? _g : 0
  };
});

export { query_get as default };
//# sourceMappingURL=query.get.mjs.map
