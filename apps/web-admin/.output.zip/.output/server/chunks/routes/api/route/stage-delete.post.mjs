import { c as defineEventHandler, r as readBody, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const stageDelete_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const id = String((_a = body == null ? void 0 : body.id) != null ? _a : "").trim();
  if (!id) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8282\u70B9 ID\u3002"
    });
  }
  const response = await backendFetch(event, "/Gameplay/StageDelete", {
    method: "POST",
    body: { id }
  });
  return unwrapApiResponse(response);
});

export { stageDelete_post as default };
//# sourceMappingURL=stage-delete.post.mjs.map
