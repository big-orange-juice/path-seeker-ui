import { c as defineEventHandler, u as useRuntimeConfig, g as createError, r as readBody, i as getHeader, j as setResponseStatus, k as setResponseHeader, l as sendStream, m as getCookie, A as ADMIN_AUTH_COOKIE_KEY } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const ADMIN_AUTH_STORE_COOKIE_KEY = "admin-auth";
const normalizeAuthorization = (value) => {
  const token = String(value != null ? value : "").trim();
  if (!token) {
    return "";
  }
  return /^bearer\s/i.test(token) ? token : `Bearer ${token}`;
};
const parsePersistedToken = (value) => {
  const raw = String(value != null ? value : "").trim();
  if (!raw) {
    return "";
  }
  try {
    const parsed = JSON.parse(decodeURIComponent(raw));
    return typeof parsed.token === "string" ? parsed.token : "";
  } catch {
    return "";
  }
};
const resolveAuthorization = (event) => {
  const headerAuthorization = normalizeAuthorization(getHeader(event, "authorization"));
  const directToken = getCookie(event, ADMIN_AUTH_COOKIE_KEY);
  const persistedToken = parsePersistedToken(getCookie(event, ADMIN_AUTH_STORE_COOKIE_KEY));
  const cookieAuthorization = normalizeAuthorization(directToken || persistedToken);
  return headerAuthorization || cookieAuthorization;
};
const send_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const config = useRuntimeConfig(event);
  const backendBaseUrl = config.backendBaseUrl;
  if (!backendBaseUrl) {
    throw createError({
      statusCode: 500,
      message: "\u670D\u52A1\u7AEF\u672A\u914D\u7F6E backendBaseUrl\u3002"
    });
  }
  const body = await readBody(event);
  const sessionId = String((_a = body == null ? void 0 : body.sessionId) != null ? _a : "").trim();
  const clientMessageId = String((_b = body == null ? void 0 : body.clientMessageId) != null ? _b : "").trim();
  const message = String((_c = body == null ? void 0 : body.message) != null ? _c : "").trim();
  if (!sessionId || !clientMessageId || !message) {
    throw createError({
      statusCode: 400,
      message: "\u4F1A\u8BDD ID\u3001\u6D88\u606F\u5E42\u7B49 ID \u4E0E\u6D88\u606F\u5185\u5BB9\u5747\u4E0D\u80FD\u4E3A\u7A7A\u3002"
    });
  }
  const authorization = resolveAuthorization(event);
  const lastEventId = getHeader(event, "last-event-id") || getHeader(event, "Last-Event-ID");
  const normalizedBaseUrl = backendBaseUrl.endsWith("/") ? backendBaseUrl : `${backendBaseUrl}/`;
  const targetUrl = new URL("Chat/send", normalizedBaseUrl);
  const headers = {
    accept: "text/event-stream",
    "content-type": "application/json"
  };
  if (authorization) {
    headers.authorization = authorization;
  }
  if (lastEventId) {
    headers["Last-Event-ID"] = lastEventId;
  }
  const upstream = await fetch(targetUrl, {
    method: "POST",
    headers,
    body: JSON.stringify({
      sessionId,
      clientMessageId,
      message
    })
  });
  if (!upstream.ok) {
    const rawText = await upstream.text();
    let backendMessage = upstream.statusText || "Chat \u6D41\u5F0F\u8BF7\u6C42\u5931\u8D25";
    let backendCode;
    let backendTraceId;
    try {
      const parsed = JSON.parse(rawText);
      backendMessage = parsed.message || backendMessage;
      backendCode = parsed.code;
      backendTraceId = (_d = parsed.traceId) != null ? _d : void 0;
    } catch {
      if (rawText.trim()) {
        backendMessage = rawText.trim().slice(0, 300);
      }
    }
    throw createError({
      statusCode: backendCode === 10002 ? 401 : upstream.status,
      message: backendMessage,
      data: {
        code: backendCode,
        message: backendMessage,
        traceId: backendTraceId
      }
    });
  }
  if (!upstream.body) {
    throw createError({
      statusCode: 502,
      message: "\u4E0A\u6E38\u672A\u8FD4\u56DE\u53EF\u8BFB\u7684\u4E8B\u4EF6\u6D41\u3002"
    });
  }
  setResponseStatus(event, 200);
  setResponseHeader(event, "Content-Type", "text/event-stream; charset=utf-8");
  setResponseHeader(event, "Cache-Control", "no-cache, no-transform");
  setResponseHeader(event, "Connection", "keep-alive");
  setResponseHeader(event, "X-Accel-Buffering", "no");
  return sendStream(event, upstream.body);
});

export { send_post as default };
//# sourceMappingURL=send.post.mjs.map
