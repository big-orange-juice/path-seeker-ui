import { d as defineEventHandler, r as readBody, c as createError, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const stageUpdate_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const id = String((_a = body == null ? void 0 : body.id) != null ? _a : "").trim();
  const routeId = String((_b = body == null ? void 0 : body.routeId) != null ? _b : "").trim();
  if (!id || !routeId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8282\u70B9 ID \u6216\u8DEF\u7EBF ID\u3002"
    });
  }
  const response = await backendFetch(event, "/api/Gameplay/StageUpdate", {
    method: "POST",
    body: {
      ...body,
      id,
      routeId
    }
  });
  return unwrapApiResponse(response);
});

export { stageUpdate_post as default };
//# sourceMappingURL=stage-update.post.mjs.map
