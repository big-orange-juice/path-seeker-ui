import { c as defineEventHandler, r as readBody, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const changeStatus_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const response = await backendFetch(event, "/Admin/ChangeStatus", {
    method: "POST",
    body: {
      adminId: String((body == null ? void 0 : body.adminId) || "").trim(),
      status: Number(body == null ? void 0 : body.status)
    }
  });
  unwrapApiResponse(response);
});

export { changeStatus_post as default };
//# sourceMappingURL=change-status.post.mjs.map
