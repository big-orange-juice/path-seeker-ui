import { c as defineEventHandler, o as readFormData, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const file_post = defineEventHandler(async (event) => {
  const formData = await readFormData(event);
  const file = formData.get("file");
  if (!(file instanceof Blob)) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u4E0A\u4F20\u6587\u4EF6\u3002"
    });
  }
  const nextFormData = new FormData();
  nextFormData.append("file", file, file.name || "file");
  const response = await backendFetch(event, "/Upload/UploadFile", {
    method: "POST",
    body: nextFormData
  });
  return unwrapApiResponse(response);
});

export { file_post as default };
//# sourceMappingURL=file.post.mjs.map
