import { d as defineEventHandler, g as getQuery, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const detail_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const id = String(query.id || "").trim();
  const response = await backendFetch(event, "/api/Route/Detail", {
    query: { id }
  });
  return unwrapApiResponse(response);
});

export { detail_get as default };
//# sourceMappingURL=detail.get.mjs.map
