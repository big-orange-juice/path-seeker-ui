import { c as defineEventHandler, h as getQuery, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const detail_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const id = String(query.id || "").trim();
  const response = await backendFetch(event, "/Route/Detail", {
    query: { id }
  });
  return unwrapApiResponse(response);
});

export { detail_get as default };
//# sourceMappingURL=detail.get.mjs.map
