import { c as defineEventHandler, u as useRuntimeConfig, g as createError, h as getQuery, q as isTechnicalHttpMessage, p as resolveHttpStatusMessage, j as setResponseStatus, k as setResponseHeader, l as sendStream, i as getHeader, m as getCookie, A as ADMIN_AUTH_COOKIE_KEY } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const ADMIN_AUTH_STORE_COOKIE_KEY = "admin-auth";
const normalizeAuthorization = (value) => {
  const token = String(value != null ? value : "").trim();
  if (!token) {
    return "";
  }
  return /^bearer\s/i.test(token) ? token : `Bearer ${token}`;
};
const parsePersistedToken = (value) => {
  const raw = String(value != null ? value : "").trim();
  if (!raw) {
    return "";
  }
  try {
    const parsed = JSON.parse(decodeURIComponent(raw));
    return typeof parsed.token === "string" ? parsed.token : "";
  } catch {
    return "";
  }
};
const resolveAuthorization = (event) => {
  const headerAuthorization = normalizeAuthorization(getHeader(event, "authorization"));
  const directToken = getCookie(event, ADMIN_AUTH_COOKIE_KEY);
  const persistedToken = parsePersistedToken(getCookie(event, ADMIN_AUTH_STORE_COOKIE_KEY));
  const cookieAuthorization = normalizeAuthorization(directToken || persistedToken);
  return headerAuthorization || cookieAuthorization;
};
const voicePreview_get = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig(event);
  const backendBaseUrl = config.backendBaseUrl;
  if (!backendBaseUrl) {
    throw createError({
      statusCode: 500,
      message: "\u670D\u52A1\u7AEF\u672A\u914D\u7F6E backendBaseUrl\u3002"
    });
  }
  const query = getQuery(event);
  const guideId = String(query.guideId || "").trim();
  if (!guideId) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u5BFC\u6E38 ID\u3002"
    });
  }
  const authorization = resolveAuthorization(event);
  const normalizedBaseUrl = backendBaseUrl.endsWith("/") ? backendBaseUrl : `${backendBaseUrl}/`;
  const targetUrl = new URL("Guide/voice-preview", normalizedBaseUrl);
  targetUrl.searchParams.set("guideId", guideId);
  const headers = {
    accept: "audio/*,application/octet-stream,*/*"
  };
  if (authorization) {
    headers.authorization = authorization;
  }
  const upstream = await fetch(targetUrl, {
    method: "GET",
    headers
  });
  if (!upstream.ok) {
    const rawText = await upstream.text();
    let backendMessage = "";
    let backendCode;
    let backendTraceId;
    try {
      const parsed = JSON.parse(rawText);
      backendMessage = String(parsed.message || "").trim();
      backendCode = parsed.code;
      backendTraceId = (_a = parsed.traceId) != null ? _a : void 0;
    } catch {
      if (rawText.trim()) {
        backendMessage = rawText.trim().slice(0, 300);
      }
    }
    const statusCode = backendCode === 10002 ? 401 : upstream.status;
    const message = backendMessage && !isTechnicalHttpMessage(backendMessage) ? backendMessage : resolveHttpStatusMessage(statusCode, "\u97F3\u8272\u8BD5\u542C\u83B7\u53D6\u5931\u8D25");
    throw createError({
      statusCode,
      message,
      data: {
        code: backendCode,
        message: backendMessage || message,
        traceId: backendTraceId
      }
    });
  }
  const contentType = upstream.headers.get("content-type") || "audio/mpeg";
  const contentLength = upstream.headers.get("content-length");
  const contentDisposition = upstream.headers.get("content-disposition");
  setResponseStatus(event, 200);
  setResponseHeader(event, "Content-Type", contentType);
  setResponseHeader(event, "Cache-Control", "private, max-age=300");
  if (contentLength) {
    setResponseHeader(event, "Content-Length", contentLength);
  }
  if (contentDisposition) {
    setResponseHeader(event, "Content-Disposition", contentDisposition);
  }
  if (upstream.body) {
    return sendStream(event, upstream.body);
  }
  const buffer = Buffer.from(await upstream.arrayBuffer());
  return buffer;
});

export { voicePreview_get as default };
//# sourceMappingURL=voice-preview.get.mjs.map
