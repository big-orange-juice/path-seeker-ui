import { c as defineEventHandler, r as readBody, g as createError, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const generate_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const body = await readBody(event);
  const stageId = String((_a = body == null ? void 0 : body.stageId) != null ? _a : "").trim();
  const prompt = String((_b = body == null ? void 0 : body.prompt) != null ? _b : "").trim();
  const idempotencyKey = String((_c = body == null ? void 0 : body.idempotencyKey) != null ? _c : "").trim();
  if (!stageId || !prompt || !idempotencyKey) {
    throw createError({
      statusCode: 400,
      message: "\u7F3A\u5C11\u8282\u70B9\u3001\u753B\u9762\u63CF\u8FF0\u6216\u8BF7\u6C42\u6807\u8BC6\u3002"
    });
  }
  if (prompt.length > 4e3) {
    throw createError({
      statusCode: 400,
      message: "\u753B\u9762\u63CF\u8FF0\u8FC7\u957F\uFF0C\u8BF7\u7CBE\u7B80\u540E\u518D\u8BD5\u3002"
    });
  }
  if (idempotencyKey.length > 128) {
    throw createError({
      statusCode: 400,
      message: "\u8BF7\u6C42\u6807\u8BC6\u65E0\u6548\u3002"
    });
  }
  const referenceImageUrls = Array.isArray(body == null ? void 0 : body.referenceImageUrls) ? body.referenceImageUrls.map((item) => String(item != null ? item : "").trim()).filter((item) => item.length > 0).slice(0, 5) : [];
  const payload = {
    stageId,
    prompt,
    idempotencyKey,
    priority: 1e4
  };
  if (referenceImageUrls.length) {
    payload.referenceImageUrls = referenceImageUrls;
  }
  const response = await backendFetch(
    event,
    "/NarrationImage/generate",
    {
      method: "POST",
      body: payload
    }
  );
  return (_d = unwrapApiResponse(response)) != null ? _d : null;
});

export { generate_post as default };
//# sourceMappingURL=generate.post.mjs.map
