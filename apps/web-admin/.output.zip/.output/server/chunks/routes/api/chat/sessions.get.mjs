import { c as defineEventHandler, e as backendFetch, f as unwrapApiResponse } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const sessions_get = defineEventHandler(async (event) => {
  var _a;
  const response = await backendFetch(event, "/Chat/sessions", {
    method: "GET"
  });
  return (_a = unwrapApiResponse(response)) != null ? _a : [];
});

export { sessions_get as default };
//# sourceMappingURL=sessions.get.mjs.map
