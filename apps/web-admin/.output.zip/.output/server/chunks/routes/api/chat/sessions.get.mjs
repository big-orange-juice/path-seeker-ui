import { d as defineEventHandler, b as backendFetch, u as unwrapApiResponse } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'ipx';

const sessions_get = defineEventHandler(async (event) => {
  var _a;
  const response = await backendFetch(event, "/api/Chat/sessions", {
    method: "GET"
  });
  return (_a = unwrapApiResponse(response)) != null ? _a : [];
});

export { sessions_get as default };
//# sourceMappingURL=sessions.get.mjs.map
