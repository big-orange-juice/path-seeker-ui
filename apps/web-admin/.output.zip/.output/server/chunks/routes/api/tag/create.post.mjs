import { c as defineEventHandler, f as unwrapApiResponse, e as backendFetch, r as readBody } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const create_post = defineEventHandler(async (event) => unwrapApiResponse(await backendFetch(event, "/Tag/Create", { method: "POST", body: await readBody(event) })));

export { create_post as default };
//# sourceMappingURL=create.post.mjs.map
