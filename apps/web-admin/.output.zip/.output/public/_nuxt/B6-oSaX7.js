import{g as a,Z as _,W as n,Y as s}from"./RGxE9Onv.js";const p=a({__name:"index",async setup(o){let e,t;return[e,t]=_(()=>n(s,{replace:!0})),await e,t(),()=>{}}});export{p as default};
