import{g as s,S as a,P as n}from"./CTcqfffZ.js";const _=s({__name:"index",async setup(o){let e,t;return[e,t]=a(()=>n("/console/museums",{replace:!0})),await e,t(),()=>{}}});export{_ as default};
