import{g as e,o,c as t}from"./CTcqfffZ.js";const a={class:"mx-auto flex w-full max-w-[1320px] flex-col gap-4"},p=e({__name:"operations",setup(s){return(c,n)=>(o(),t("div",a))}});export{p as default};
